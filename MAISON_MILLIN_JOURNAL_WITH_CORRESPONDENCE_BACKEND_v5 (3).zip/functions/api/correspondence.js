function isAllowedOrigin(origin) {
  try {
    const url = new URL(origin);
    return url.protocol === "https:" &&
      (url.hostname === "maison-millin-preview.pages.dev" ||
       url.hostname.endsWith(".maison-millin-preview.pages.dev"));
  } catch {
    return false;
  }
}

const RECIPIENT = "maisonmillinny@gmail.com";
const INTENTS = new Set(["general", "creation", "bespoke"]);
const CREATIONS = new Set([
  "yellow-tiger",
  "golden-peacock",
  "graceful-crane",
  "starry-night",
  "royal-wave",
  "maestro-guilloche",
]);

const json = (data, status, origin) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    ...(origin && isAllowedOrigin(origin) ? {
      "access-control-allow-origin": origin,
      "access-control-allow-methods": "POST, OPTIONS",
      "access-control-allow-headers": "Content-Type",
      "vary": "Origin",
    } : {}),
  },
});

const clean = (value, max) =>
  typeof value === "string" ? value.trim().slice(0, max) : "";

const escapeHtml = (value) => value.replace(/[&<>"']/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
}[char]));

function validate(input) {
  const errors = {};
  const name = clean(input.name, 120);
  const email = clean(input.email, 254);
  const intent = clean(input.intent, 30);
  const creation = clean(input.creation, 60);
  const message = clean(input.message, 3000);

  if (name.length < 2 || name.length > 120) errors.name = "Please enter your name (2–120 characters).";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = "Please enter a valid email address.";
  if (!INTENTS.has(intent)) errors.intent = "Please choose the subject of your message.";
  if (intent === "creation" && !CREATIONS.has(creation)) errors.creation = "Please choose a creation.";
  if (message.length < 10 || message.length > 3000) errors.message = "Please write a message (10–3,000 characters).";

  if (Object.keys(errors).length) return { errors };
  return { value: { name, email, intent, creation: intent === "creation" ? creation : "", message } };
}

function subjectFor(data) {
  const labels = {
    general: "General enquiry",
    creation: `Enquiry — ${data.creation.replaceAll("-", " ")}`,
    bespoke: "Bespoke commission enquiry",
  };
  return `MAISON MILLIN Correspondence — ${labels[data.intent]}`;
}

export async function onRequest(context) {
  const { request, env } = context;
  const origin = request.headers.get("Origin") || "";

  if (request.method === "OPTIONS") {
    if (!isAllowedOrigin(origin)) return new Response(null, { status: 403 });
    return new Response(null, {
      status: 204,
      headers: {
        "access-control-allow-origin": origin,
        "access-control-allow-methods": "POST, OPTIONS",
        "access-control-allow-headers": "Content-Type",
        "access-control-max-age": "86400",
        "vary": "Origin",
      },
    });
  }

  if (request.method !== "POST") {
    return json({ error: "Method not allowed." }, 405, origin);
  }
  if (!isAllowedOrigin(origin)) {
    return json({ error: "Origin not allowed." }, 403);
  }
  if (!(request.headers.get("content-type") || "").toLowerCase().includes("application/json")) {
    return json({ error: "Content-Type must be application/json." }, 415, origin);
  }

  const declaredLength = Number(request.headers.get("content-length") || 0);
  if (declaredLength > 12_000) return json({ error: "Request too large." }, 413, origin);

  let input;
  try {
    const raw = await request.text();
    if (raw.length > 12_000) return json({ error: "Request too large." }, 413, origin);
    input = JSON.parse(raw);
  } catch {
    return json({ error: "Invalid JSON." }, 400, origin);
  }

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return json({ error: "Invalid request." }, 400, origin);
  }

  // Honeypot: return the same accepted response without sending spam.
  if (clean(input.website, 200)) return json({ accepted: true }, 202, origin);

  const result = validate(input);
  if (result.errors) return json({ errors: result.errors }, 400, origin);

  if (!env.RESEND_API_KEY || !env.EMAIL_FROM) {
    return json({ error: "Correspondence delivery is not configured." }, 503, origin);
  }

  const data = result.value;
  const textBody = [
    "MAISON MILLIN — PRIVATE CORRESPONDENCE",
    "",
    `Name: ${data.name}`,
    `Email: ${data.email}`,
    `Subject: ${data.intent}`,
    ...(data.creation ? [`Creation: ${data.creation}`] : []),
    "",
    data.message,
  ].join("\n");

  const htmlBody = `
    <div style="font-family:Arial,sans-serif;color:#161616;line-height:1.6">
      <p style="letter-spacing:.18em;font-size:11px;color:#9A8968">MAISON MILLIN · PRIVATE CORRESPONDENCE</p>
      <h2 style="font-weight:400">A new enquiry has been received</h2>
      <p><strong>Name:</strong> ${escapeHtml(data.name)}</p>
      <p><strong>Email:</strong> ${escapeHtml(data.email)}</p>
      <p><strong>Subject:</strong> ${escapeHtml(data.intent)}</p>
      ${data.creation ? `<p><strong>Creation:</strong> ${escapeHtml(data.creation)}</p>` : ""}
      <hr style="border:0;border-top:1px solid #ddd;margin:24px 0">
      <p style="white-space:pre-wrap">${escapeHtml(data.message)}</p>
    </div>`;

  let delivery;
  try {
    delivery = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "authorization": `Bearer ${env.RESEND_API_KEY}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        from: env.EMAIL_FROM,
        to: [RECIPIENT],
        reply_to: data.email,
        subject: subjectFor(data),
        text: textBody,
        html: htmlBody,
      }),
    });
  } catch {
    return json({ error: "Email provider is temporarily unavailable." }, 503, origin);
  }

  if (!delivery.ok) {
    // Do not expose provider response or credentials to the public client.
    return json({ error: "Message could not be delivered. Please try again later." }, 503, origin);
  }

  return json({ accepted: true }, 202, origin);
}
