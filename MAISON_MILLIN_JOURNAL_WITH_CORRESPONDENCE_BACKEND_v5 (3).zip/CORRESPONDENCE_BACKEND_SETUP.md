# MAISON MILLIN Correspondence backend

Cloudflare Pages Function: `functions/api/correspondence.js`

## Delivery
- Fixed recipient: `maisonmillinny@gmail.com`
- Provider: Resend API (`https://api.resend.com/emails`)
- Sender: configured with the Cloudflare Pages environment variable `EMAIL_FROM`
- Secret: `RESEND_API_KEY` (Cloudflare Pages secret; never commit it)
- Visitor email is used only as `Reply-To`; the visitor cannot choose the recipient.

## Required Cloudflare Preview variables
Set these under Pages → `maison-millin-preview` → Settings → Environment variables → Preview:
- Secret `RESEND_API_KEY`: API key from Resend.
- Variable `EMAIL_FROM`: a sender identity on a domain verified in Resend, e.g. `MAISON MILLIN <correspondence@maisonmillin.com>`.

Do not put the Resend key in source control or in a `VITE_` variable.
Production variables are intentionally not part of this Preview setup.

## Request contract
POST `/api/correspondence`, JSON:
`{ "name": "...", "email": "...", "intent": "general|creation|bespoke", "creation": "...", "message": "...", "website": "" }`

Responses:
- `202` accepted and sent
- `400` validation errors
- `403` disallowed origin
- `405` wrong method
- `413` oversized request
- `415` wrong content type
- `503` provider/configuration failure

Security:
- fixed recipient, strict Preview origin allowlist, body-size limit, input validation,
  HTML escaping, honeypot, no public exposure of provider errors or credentials.
- No message database or retention is added; messages are delivered by email only.

Before live use, verify the sender domain in Resend and add the two Preview variables above.
A real email delivery test is required after those values are configured.
